/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.compiproyectofinaldosjordan;
/**
 *
 * @author erickortiz
 */
import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

public class Arbol 
{
    private final Nodo raiz;
    //TablaSimbolos tablaSimbolos;
    static private final Stack<Object> pilaArbol;
   
    static 
    {
        pilaArbol = new Stack<>();
    }
    
    public Arbol(Nodo raiz)
    {
       // tablaSimbolos = new TablaSimbolos();
        this.raiz = raiz; 
       

    }

    public void recorrer()     
    {   

        
        
        
        Object valor;
        String identificador ;
      
        
        for(Nodo n : raiz.getHijos())
        {
            Token t = n.getValue();
            switch (t.tipo)
            {
                // Operadores aritméticos
            
                case MAS:
                case MENOS:
                case ASTERISCO:
                case ENTRE:
                    SolverAritmetico solver = new SolverAritmetico(n);
                    Object res = solver.resolver();
                    System.out.println(res);
                break;

                case VAR:
                    /*
                    // Crear una variable. Usar tabla de simbolos
              identificador = "var"; // Assuming the identifier value is stored in the Nodo object
                if (tablaSimbolos.existeIdentificador(identificador) )
                {
                    throw new RuntimeException("Variable already defined: '" + identificador + "'.");
                }

                // Obtain the value for the variable from the AST (assuming it's stored in the Nodo object)
               valor = n.getValue(); // Replace this with the appropriate way to obtain the value

                tablaSimbolos.asignar(identificador, valor); // Add the variable to the symbol table
                break;
                    
 */
                identificador = n.getHijos().get(0).getValue().getLexema();// Extract the identifier from the Token
                 
               // if (tablaSimbolos.existeIdentificador(identificador)) 
                if (TablaSimbolos.existeIdentificador(identificador))
                {
                        throw new RuntimeException("Variable already defined: '" + identificador + "'.");
                    }
                else{           //Para obtener solamente el double:
                 
                    double numericValue = Double.parseDouble(n.getHijos().get(1).getValue().getLexema());
                // valor = n.getHijos().get(1).getValue(); // Extract the value from the first child Token
                 if(TablaSimbolos.asignar(identificador, numericValue))
                    {
                    
                    pilaArbol.push(numericValue);
                    }
                }
                 
                 
                    break;

                
              /*  case PRINT:
                   
                   //TablaSimbolos.imprimirTabla();
                   String varToPrint = n.getHijos().get(0).getValue().getLexema(); // Extract the variable identifier from the first child Token
                   //System.out.println("NUESTRA VARIABLE CUYO CONTENIDO IMPRIMIREMOS ES: " + varToPrint);
                    if (TablaSimbolos.existeIdentificador(varToPrint)) 
                    {
                        Object valueToPrint = TablaSimbolos.obtener(varToPrint);
                        System.out.println(varToPrint + "=" + valueToPrint);
                    } 
                    else 
                    {
                       throw new RuntimeException("VARIABLE NO ENCONTRADA ! '" + varToPrint + "'.");
                    }
                    break;
                    
                   */ 
                    
                   
case PRINT:
    List<Nodo> printHijos = n.getHijos();
    StringBuilder output = new StringBuilder();

    for (Nodo printNode : printHijos) 
    {
        Token token = printNode.getValue();

        if (token.tipo == TipoToken.MAS) 
        {
            if (pilaArbol.size() < 2)
            {
                throw new RuntimeException("Insufficient operands for addition.");
            }
            
            // Perform addition operation
            double operand2 = (double) pilaArbol.pop();
            double operand1 = (double) pilaArbol.pop();
            double result = operand1 + operand2;
            //pilaArbol.push(result);
            //System.out.println(pilaArbol.lastElement());
            System.out.println(result);
            pilaArbol.push(operand1);
            pilaArbol.push(operand2);
        } 
        else  if (token.tipo == TipoToken.MENOS) 
        {
            if (pilaArbol.size() < 2)
            {
                throw new RuntimeException("Insufficient operands for addition.");
            }
            
            // Perform addition operation
            double operand2 = (double) pilaArbol.pop();
            double operand1 = (double) pilaArbol.pop();
            double result = operand1 - operand2;
            //pilaArbol.push(result);
            //System.out.println(pilaArbol.lastElement());
            System.out.println(result);
            pilaArbol.push(operand1);
            pilaArbol.push(operand2);
            
        } 
       
          else  if (token.tipo == TipoToken.ASTERISCO) 
        {
            if (pilaArbol.size() < 2)
            {
                throw new RuntimeException("Insufficient operands for addition.");
            }
            
            // Perform addition operation
            double operand2 = (double) pilaArbol.pop();
            double operand1 = (double) pilaArbol.pop();
            double result = operand1 * operand2;
            //pilaArbol.push(result);
            //System.out.println(pilaArbol.lastElement());
            System.out.println(result);
            pilaArbol.push(operand1);
            pilaArbol.push(operand2);
            
        } 
       
          else  if (token.tipo == TipoToken.ENTRE) 
        {
            if (pilaArbol.size() < 2)
            {
                throw new RuntimeException("Insufficient operands for addition.");
            }
            
            // Perform addition operation
            double operand2 = (double) pilaArbol.pop();
            double operand1 = (double) pilaArbol.pop();
            double result = operand1 / operand2;
            //pilaArbol.push(result);
            //System.out.println(pilaArbol.lastElement());
            System.out.println(result);
            pilaArbol.push(operand1);
            pilaArbol.push(operand2);
            
        } 
                
                //print a;
        else if (token.tipo == TipoToken.IDENTIFICADOR) 
        {
            String varToPrint = token.getLexema();
            if (TablaSimbolos.existeIdentificador(varToPrint)) 
            {
                Object valueToPrint = TablaSimbolos.obtener(varToPrint);
                output.append(valueToPrint);
                pilaArbol.push(valueToPrint);
                System.out.println(output);
            } else 
            {
                throw new RuntimeException("Variable not found: '" + varToPrint + "'.");
            }
        } 
        else if (token.tipo == TipoToken.STRING) 
        {
            String stringValue = token.getLexema();
            //output.append(stringValue);
            System.out.println(stringValue);
        }
    }

    
    break;
   
                    
              // case IF:
              /*     
                 // Crear una variable. Usar tabla de simbolos
              identificador = "if"; // Assuming the identifier value is stored in the Nodo object
                if (tablaSimbolos.existeIdentificador(identificador) )
                {
                    throw new RuntimeException("Variable already defined: '" + identificador + "'.");
                }

                // Obtain the value for the variable from the AST (assuming it's stored in the Nodo object)
                 valor = n.getValue(); // Replace this with the appropriate way to obtain the value

                tablaSimbolos.asignar(identificador, valor); // Add the variable to the symbol table
                break;
                   */

            }
        }
        // TablaSimbolos.imprimirTabla();
         
       
    }
 
    
     

    }
