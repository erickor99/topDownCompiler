/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.compiproyectofinaldosjordan;

/**
 *
 * @author erickortiz
 */
import java.util.ArrayList;
import java.util.List;

import java.util.Collections;

public class Parser 
{

    private final List<Token> tokens;
    private final List<Token> tokensAceptadosPorParser = new ArrayList<>();

    //private final Token identificador = new Token(TipoToken.IDENTIFICADOR, "");
    
    private final Token clase = new Token (TipoToken.CLASS, "class");
    private final Token identificador = new Token (TipoToken.IDENTIFICADOR, "");
    private final Token menorque = new Token (TipoToken.MENORQUE, "<");
    private final Token funcion = new Token (TipoToken.FUN, "fun");
    private final Token var = new Token (TipoToken.VAR, "var");
    private final Token igual = new Token (TipoToken.IGUAL, "=");
    private final Token keybFor = new Token (TipoToken.FOR, "for");
    private final Token puntoycoma = new Token (TipoToken.PUNTOYCOMA, ";");
    private final Token keybIf = new Token (TipoToken.IF, "if");
    private final Token parentesisabre = new Token (TipoToken.PARENTESISABRE, "(");
    private final Token parentesiscierra = new Token (TipoToken.PARENTESISCIERRA,")" );
    private final Token keybElse = new Token (TipoToken.ELSE, "else");
    private final Token keybPrint = new Token (TipoToken.PRINT, "print");
    private final Token keybReturn = new Token (TipoToken.RETURN, "return");
    private final Token keybWhile = new Token (TipoToken.WHILE, "while");
    private final Token llaveabre = new Token (TipoToken.LLAVEABRE, "{");
    private final Token llavecierra = new Token (TipoToken.LLAVECIERRA, "}");
    private final Token or = new Token (TipoToken.OR, "or");
    private final Token and = new Token (TipoToken.AND, "and");
    private final Token diferentede = new Token (TipoToken.DIFERENTEDE, "!=");
    private final Token igualcomparar = new Token (TipoToken.IGUALCOMPARAR, "==");
    private final Token mayorque = new Token (TipoToken.MAYORQUE, ">");
    private final Token mayorigualque = new Token (TipoToken.MAYOROIGUALQUE, ">=");
    private final Token menorigualque = new Token (TipoToken.MENORIGUALQUE, "<=");
    private final Token menos = new Token (TipoToken.MENOS, "-");
    private final Token mas = new Token (TipoToken.MAS, "+");
    private final Token entre = new Token (TipoToken.ENTRE, "/");
    private final Token complementologico = new Token (TipoToken.COMPLEMENTOLOGICO, "!");
    private final Token keybTrue = new Token (TipoToken.TRUE, "true");
    private final Token keybFalse = new Token (TipoToken.FALSE, "false");
    private final Token keybNull = new Token (TipoToken.NULL, "null");
    private final Token keybThis = new Token (TipoToken.THIS, "this");
    private final Token number = new Token (TipoToken.NUMBER, "number");
    private final Token string = new Token (TipoToken.STRING, "string");
    private final Token keybSuper = new Token (TipoToken.SUPER, "super");
    private final Token coma = new Token(TipoToken.COMA, ",");
    private final Token punto = new Token(TipoToken.PUNTO, ".");
    private final Token asterisco = new Token(TipoToken.ASTERISCO, "*");
    private final Token finCadena = new Token(TipoToken.EOF, "");
     private final Token newline = new Token(TipoToken.NEWLINE, "\n");


    private int i = 0;
    private boolean hayErrores = false;

    private Token preanalisis;

    public Parser(List<Token> tokens)
    {
        this.tokens = tokens;
    }

    public void parse()
    {
        i = 0;
        preanalisis = tokens.get(i);
      // System.out.println("Voy a buscar el token:" + preanalisis.tipo);
        PROGRAM();

        if(!hayErrores && !preanalisis.equals(finCadena))
        {
            System.out.println("Error en la posición " + preanalisis.posicion + ". No se esperaba el token " + preanalisis.tipo);
            //return Collections.emptyList();
        }
        else if(!hayErrores && preanalisis.equals(finCadena)){
            System.out.println("Consulta válida");
           // return tokensAceptadosPorParser;
        }
        
        //return Collections.emptyList();
        /*if(!preanalisis.equals(finCadena)){
            System.out.println("Error en la posición " + preanalisis.posicion + ". No se esperaba el token " + preanalisis.tipo);
        }else if(!hayErrores){
            System.out.println("Consulta válida");
        }*/
        
    }

    void PROGRAM()
    {
            //-> DECLARATION
     
       
       // if(preanalisis.equals(newline))
      //      {
          //  i++;     
        //    }
       //  System.out.println("Apunto de evaluar PROGRAM()");   
        if(preanalisis.equals(clase))
        {
            DECLARATION();
 
        }

                
        else if(preanalisis.equals(funcion))
        {
        DECLARATION();
            
        }
        

        else if(preanalisis.equals(var))
        {
            DECLARATION();
            
        }
        
    
        else if(preanalisis.equals(complementologico) ||preanalisis.equals(menos)||preanalisis.equals(keybTrue)||preanalisis.equals(keybFalse)||preanalisis.equals(keybNull)||preanalisis.equals(keybThis)||preanalisis.equals(number)||preanalisis.equals(string)||preanalisis.equals(identificador)||preanalisis.equals(parentesisabre)||preanalisis.equals(keybSuper)||preanalisis.equals(keybFor) || preanalisis.equals(keybIf)|| preanalisis.equals(keybPrint) ||preanalisis.equals(keybReturn) || preanalisis.equals(keybWhile)|| preanalisis.equals(llaveabre))
        {
            DECLARATION();
        }
        

        else 
            {
            return;
            }
        
    }

    void DECLARATION()
    {
        if(hayErrores) return;
        
                //-> CLASS_DECL DECLARATION
        if(preanalisis.equals(clase))
        {
            CLASS_DECL();
            DECLARATION();
 
        }
        
        
                //-> FUN_DECL DECLARATION
        else if(preanalisis.equals(funcion))
        {
             FUN_DECL();
             DECLARATION();
            
        }
        
                //-> VAR_DECL DECLARATION
        
        else if(preanalisis.equals(var))
        {
            VAR_DECL();
            DECLARATION();
            
        }
        
                //DECLARATION-> STATEMENT DECLARATION
        else if(preanalisis.equals(complementologico)||preanalisis.equals(menos)||preanalisis.equals(keybTrue)||preanalisis.equals(keybFalse)||preanalisis.equals(keybNull)||preanalisis.equals(keybThis)||preanalisis.equals(number)||preanalisis.equals(string)||preanalisis.equals(identificador)||preanalisis.equals(parentesisabre)||preanalisis.equals(keybSuper) ||preanalisis.equals(keybFor) || preanalisis.equals(keybIf)|| preanalisis.equals(keybPrint) ||preanalisis.equals(keybReturn) || preanalisis.equals(keybWhile)|| preanalisis.equals(llaveabre))
        {
            STATEMENT();
            DECLARATION();
            
        }
        
               
            //-> Ɛ   
        else 
            {
            return;
            }
    }

    void CLASS_DECL() 
    {
        if(hayErrores) return;

        if(preanalisis.equals(clase)){
            coincidir(clase);
            coincidir(identificador);
            CLASS_INHER();
            coincidir(llaveabre);
            FUNCTIONS();
            coincidir(llavecierra);
        }

    }

    void CLASS_INHER()
    {
        if(hayErrores) return;

        if(preanalisis.equals(menorque)){
           coincidir(menorque);
           coincidir(identificador);
          
        }
        else{
            return;
        }
    }

    void FUN_DECL(){
        if(hayErrores) return;

        if(preanalisis.equals(funcion))
        {
            coincidir(funcion);
            FUNCTION();
        }
    }

    void VAR_DECL() {
        if(hayErrores) return;

        if(preanalisis.equals(var))
        {
                
           // System.out.println("Llegamos exitosos a VAR_DECL");
           // System.out.println("Valor de preanalisis en lexema" + preanalisis.lexema + "Valor de preanalisis en tipo");
            coincidir(var);
            coincidir(identificador);
           // System.out.println("Apppunto de llamar a VAR_INIT y mi preanalisis tipo es: " + preanalisis.tipo);
            VAR_INIT();
            coincidir(puntoycoma);
        }

            }

    void VAR_INIT()
    {
        if(hayErrores) return;

        if(preanalisis.equals(igual))
        {
            coincidir(igual);
            EXPRESSION();
        }
        else
            {   
               // System.out.println("retornando desde var_init");
                return;
            
            }
        
        
    }
    
    
   
    void STATEMENT()
    {
        if(hayErrores) return;
                
        //->EXPR_STMT
        if(preanalisis.equals(complementologico) )
        {
           EXPR_STMT();
        }
        if(preanalisis.equals(menos) )
        {
           EXPR_STMT();
        }
        else if (preanalisis.equals(keybTrue))
            {
           EXPR_STMT();
            }
        else if (preanalisis.equals(keybFalse))
            {
            
         EXPR_STMT();
            }
        else if (preanalisis.equals(keybNull))
            {
            
           EXPR_STMT();
            }
        else if (preanalisis.equals(keybThis))
            {
            
           EXPR_STMT();
            }
        else if (preanalisis.equals(number))
            {
            
          EXPR_STMT();
            }
        else if (preanalisis.equals(string))
            {
            
            EXPR_STMT();
            }
        else if (preanalisis.equals(identificador))
            {
            
          EXPR_STMT();
            }
        else if (preanalisis.equals(parentesisabre))
            {
            
          EXPR_STMT();
            
            }
       else if (preanalisis.equals(keybSuper))
            {
            
         EXPR_STMT();
            
            }
       
        
                
        ////->FOR_STMT
        else if (preanalisis.equals(keybFor))
            {
                FOR_STMT();
            
            }
       //-> IF_STMT
        else if ( preanalisis.equals(keybIf))
              {
              IF_STMT();
              }
        
        //-> PRINT_STMT
        else if ( preanalisis.equals(keybPrint))
            {
            PRINT_STMT();
            }
        
        //-> RETURN_STMT
        else if(preanalisis.equals(keybReturn))
            {
            RETURN_STMT();
            }
        
        //-> WHILE_STMT
        else if (preanalisis.equals(keybWhile))
            {
            WHILE_STMT();
            
            }
        
       // -> BLOCK
        else if (preanalisis.equals(llaveabre))
            {
            BLOCK();
            
            }

    }
    
    

    void EXPR_STMT()
    {
        if(hayErrores) return;

        if(preanalisis.equals(complementologico))
        {
            EXPRESSION();
            coincidir(puntoycoma);
        }
        
        else if (preanalisis.equals(menos))
            {
            EXPRESSION();
            coincidir(puntoycoma);
            }
        
        
        
        else if (preanalisis.equals(keybTrue))
            {
            EXPRESSION();
            coincidir(puntoycoma);
            }
        else if (preanalisis.equals(keybFalse))
            {
            
          EXPRESSION();
          coincidir(puntoycoma);
            }
        else if (preanalisis.equals(keybNull))
            {
            
           EXPRESSION();
           coincidir(puntoycoma);
            }
        else if (preanalisis.equals(keybThis))
            {
            
            EXPRESSION();
            coincidir(puntoycoma);
            }
        else if (preanalisis.equals(number))
            {
            
           EXPRESSION();
           coincidir(puntoycoma);
            }
        else if (preanalisis.equals(string))
            {
            
            EXPRESSION();
            coincidir(puntoycoma);
            }
        else if (preanalisis.equals(identificador))
            {
            
           EXPRESSION();
           coincidir(puntoycoma);
            }
        else if (preanalisis.equals(parentesisabre))
            {
            
           EXPRESSION();
           coincidir(puntoycoma);
            
            }
       else if (preanalisis.equals(keybSuper))
            {
            
         EXPRESSION();
         coincidir(puntoycoma);
            
            }
        
        
    }

    void FOR_STMT()
    {
        if(hayErrores) return;

          
        if(preanalisis.equals(keybFor))
        {
            coincidir(keybFor);
            coincidir(parentesisabre);
             FOR_STMT_1();
             FOR_STMT_2();
             FOR_STMT_3();
             coincidir(parentesiscierra);
             STATEMENT();
            
        }

    }

    void FOR_STMT_1()
    {
        if(hayErrores) return;
           // -> VAR_DECL
        if(preanalisis.equals(var))
        {
            VAR_DECL();
        }
            //-> EXPR_STMT
        else if(preanalisis.equals(complementologico)|preanalisis.equals(menos) | preanalisis.equals(keybTrue)| preanalisis.equals(keybFalse)| preanalisis.equals(keybNull)| preanalisis.equals(keybThis)| preanalisis.equals(number)| preanalisis.equals(string)| preanalisis.equals(identificador)| preanalisis.equals(parentesisabre)| preanalisis.equals(keybSuper))
            {
            EXPR_STMT();
            }
       // -> ;
        else if(preanalisis.equals(puntoycoma))
            {
            coincidir(puntoycoma);
            }
    }
    
    
    void FOR_STMT_2()
    {
        if(hayErrores) return;

            //->EXPRESSION;

       if(preanalisis.equals(complementologico)|preanalisis.equals(menos) | preanalisis.equals(keybTrue)| preanalisis.equals(keybFalse)| preanalisis.equals(keybNull)| preanalisis.equals(keybThis)| preanalisis.equals(number)| preanalisis.equals(string)| preanalisis.equals(identificador)| preanalisis.equals(parentesisabre)| preanalisis.equals(keybSuper))
            {
            EXPRESSION();
            coincidir(puntoycoma);
            }
       
       //-> ;
       else if (preanalisis.equals(puntoycoma))
            {
            coincidir(puntoycoma);
            
            }
        
        
    }
    
    void FOR_STMT_3(){
        if(hayErrores) return;
            //->EXPRESSION
       if(preanalisis.equals(complementologico)|preanalisis.equals(menos) | preanalisis.equals(keybTrue)| preanalisis.equals(keybFalse)| preanalisis.equals(keybNull)| preanalisis.equals(keybThis)| preanalisis.equals(number)| preanalisis.equals(string)| preanalisis.equals(identificador)| preanalisis.equals(parentesisabre)| preanalisis.equals(keybSuper))
            {
            EXPRESSION();
            }
       
            //->E
       else
         {
         return;
         }
       
       
    }
        
        
     void IF_STMT()
     {
        if(hayErrores) return;
            //->if (EXPRESSION) STATEMENT ELSE_STATEMENT
        if(preanalisis.equals(keybIf))
        {
            coincidir(keybIf);
            coincidir(parentesisabre);
            EXPRESSION();
            coincidir(parentesiscierra);
            STATEMENT();
            ELSE_STATEMENT();
        }
    }
         
     
     
    void ELSE_STATEMENT()
    {
        if(hayErrores) return;
            //->else STATEMENT
        if(preanalisis.equals(keybElse))
        {
            coincidir(keybElse);
            STATEMENT();
        }
            //->E
        else 
        {
            return;
        }
        
    }
     
     
   void PRINT_STMT()
   {
        if(hayErrores) return;
            //->print EXPRESSION ;
        if(preanalisis.equals(keybPrint))
        {
            coincidir(keybPrint);
            EXPRESSION();
            coincidir(puntoycoma);
        }
       
    }
    
   
  void RETURN_STMT(){
        if(hayErrores) return;
          // -> return RETURN_EXP_OPC ;
        if(preanalisis.equals(keybReturn))
        {
            coincidir(keybReturn);
            RETURN_EXP_OPC();
            coincidir(puntoycoma);
        }
    }
    
      
   void RETURN_EXP_OPC(){
        if(hayErrores) return;
            //-> EXPRESSION
       if(preanalisis.equals(complementologico)|preanalisis.equals(menos) | preanalisis.equals(keybTrue)| preanalisis.equals(keybFalse)| preanalisis.equals(keybNull)| preanalisis.equals(keybThis)| preanalisis.equals(number)| preanalisis.equals(string)| preanalisis.equals(identificador)| preanalisis.equals(parentesisabre)| preanalisis.equals(keybSuper))
            {
            EXPRESSION();
            }
       
            //E
        else
        {
            return;
        }
    }
    
    
   
   void WHILE_STMT(){
        if(hayErrores) return;
            //->while ( EXPRESSION ) STATEMENT
        if(preanalisis.equals(keybWhile))
        {
            coincidir(keybWhile);
            coincidir(parentesisabre);
            EXPRESSION();
            coincidir(parentesiscierra);
            STATEMENT();
        }
    }
      
      
    void BLOCK()
    {           
        if(hayErrores) return;
            //->{ BLOCK_DECL }
        if(preanalisis.equals(llaveabre)){
            //System.out.println("DENTRO DEL IF DEL BLOCKKKKKK");
            coincidir(llaveabre);
            BLOCK_DECL();
            coincidir(llavecierra);
        }
    }
  
    
    
   void BLOCK_DECL()
   {
        if(hayErrores) return;
           //-> DECLARATION BLOCK_DECL
        if(preanalisis.equals(clase)|preanalisis.equals(funcion)|preanalisis.equals(var))
        {
            DECLARATION();
            BLOCK_DECL();
        }
                        //EXPRESSION
       else if(preanalisis.equals(complementologico)|preanalisis.equals(menos) | preanalisis.equals(keybTrue)| preanalisis.equals(keybFalse)| preanalisis.equals(keybNull)| preanalisis.equals(keybThis)| preanalisis.equals(number)| preanalisis.equals(string)| preanalisis.equals(identificador)| preanalisis.equals(parentesisabre)| preanalisis.equals(keybSuper))
            {
            DECLARATION();
            BLOCK_DECL();
            }
       else if(preanalisis.equals(keybFor))
             {
             DECLARATION();
            BLOCK_DECL();
             
             }
        else if(preanalisis.equals(keybIf))
             {
             DECLARATION();
            BLOCK_DECL();
             
             }
         else if(preanalisis.equals(keybPrint))
             {
             //System.out.println("DENTRO DEL ELSE IF DEL BLOCK_DECL");
             DECLARATION();
            BLOCK_DECL();
             
             }
         else if(preanalisis.equals(keybReturn))
             {
             DECLARATION();
            BLOCK_DECL();
             
             }
          else if(preanalisis.equals(keybWhile))
             {
             DECLARATION();
            BLOCK_DECL();
             
             }
          else if(preanalisis.equals(llaveabre))
             {
            DECLARATION();
            BLOCK_DECL();
             
             }
           
        
        
            //->E
        else
            {return;}
    }
  
   
   
   
   
    void EXPRESSION()
   {
        if(hayErrores) return;
            //->ASSIGNMENT
        if(preanalisis.equals(complementologico)|preanalisis.equals(menos))
        {
            ASSIGNMENT();
        }
        else if(preanalisis.equals(keybTrue)| preanalisis.equals(keybFalse)| preanalisis.equals(keybNull)| preanalisis.equals(keybThis)| preanalisis.equals(number)| preanalisis.equals(string)| preanalisis.equals(identificador)| preanalisis.equals(parentesisabre)| preanalisis.equals(keybSuper))
           
            {
            ASSIGNMENT();
            }
    }
       
    
      
    void ASSIGNMENT()
   {
        if(hayErrores) return;
            //->LOGIC_OR ASSIGNMENT_OPC
      if(preanalisis.equals(complementologico)|preanalisis.equals(menos))
        {
            LOGIC_OR();
            ASSIGNMENT_OPC();
        }
        else if(preanalisis.equals(keybTrue)| preanalisis.equals(keybFalse)| preanalisis.equals(keybNull)| preanalisis.equals(keybThis)| preanalisis.equals(number)| preanalisis.equals(string)| preanalisis.equals(identificador)| preanalisis.equals(parentesisabre)| preanalisis.equals(keybSuper))
           
            {
            LOGIC_OR();
            ASSIGNMENT_OPC();
            }
        
    }
       
    
      
    void ASSIGNMENT_OPC()
   {
        if(hayErrores) return;
            //-> = EXPRESSION
        if(preanalisis.equals(igual)){
            coincidir(igual);
            EXPRESSION();
        }
            //->E
        else
            return;
    }
    
    
    
   void LOGIC_OR()
   {
        if(hayErrores) return;
            //->LOGIC_AND LOGIC_OR_2
      if(preanalisis.equals(complementologico)|preanalisis.equals(menos))
        {
            LOGIC_AND();
            LOGIC_OR_2();
        }
        else if(preanalisis.equals(keybTrue)| preanalisis.equals(keybFalse)| preanalisis.equals(keybNull)| preanalisis.equals(keybThis)| preanalisis.equals(number)| preanalisis.equals(string)| preanalisis.equals(identificador)| preanalisis.equals(parentesisabre)| preanalisis.equals(keybSuper))
           
            {
            LOGIC_AND();
            LOGIC_OR_2();
            }
    }
   
        
    void LOGIC_OR_2()
   {
        if(hayErrores) return;
            // -> or LOGIC_AND LOGIC_OR_2
        if(preanalisis.equals(or)){
            coincidir(or);
            LOGIC_AND();
            LOGIC_OR_2();
        }
               //->E
        else
            return;
    }
    
    
    
  
   void LOGIC_AND()
   {
        if(hayErrores) return;
            //-> EQUALITY LOGIC_AND_2

         if(preanalisis.equals(complementologico)|preanalisis.equals(menos))
        {
            EQUALITY();
            LOGIC_AND_2();
        }
        else if(preanalisis.equals(keybTrue)| preanalisis.equals(keybFalse)| preanalisis.equals(keybNull)| preanalisis.equals(keybThis)| preanalisis.equals(number)| preanalisis.equals(string)| preanalisis.equals(identificador)| preanalisis.equals(parentesisabre)| preanalisis.equals(keybSuper))
           
            {
            EQUALITY();
            LOGIC_AND_2();
            }
        
    }
       
        
             
    void LOGIC_AND_2()
   {
        if(hayErrores) return;
        //-> and EQUALITY LOGIC_AND_2
        if(preanalisis.equals(and)){
            coincidir(and);
            EQUALITY();
            LOGIC_AND_2();
        }
            //->E
        else
                return;
    }
    
    
    
    
    void EQUALITY()
   {
        if(hayErrores) return;
            //-> COMPARISON EQUALITY_2
         if(preanalisis.equals(complementologico)|preanalisis.equals(menos))
        {
            COMPARISON();
            EQUALITY_2();
        }
        else if(preanalisis.equals(keybTrue)| preanalisis.equals(keybFalse)| preanalisis.equals(keybNull)| preanalisis.equals(keybThis)| preanalisis.equals(number)| preanalisis.equals(string)| preanalisis.equals(identificador)| preanalisis.equals(parentesisabre)| preanalisis.equals(keybSuper))
           
            {
            COMPARISON();
            EQUALITY_2();
            }
    }
        
       
        
   void EQUALITY_2()
   {
        if(hayErrores) return;
        //-> != COMPARISON EQUALITY_2
        if(preanalisis.equals(complementologico))
        {
            coincidir(complementologico);
            coincidir(igual);
            COMPARISON();
            EQUALITY_2();
        }
        //> == COMPARISON EQUALITY_2
        else if (preanalisis.equals(igual))
            {
                //coincidir(igual);
              //  System.out.println("AquiVIENE EL PROBLEMA ATENTOOOOOOOOO");
                coincidir(igual);
                COMPARISON();
                EQUALITY_2();
            }
        
            //->E
        else
            return;
    }
            
   
       
    void COMPARISON()
   {
        if(hayErrores) return;
            
        //-> TERM COMPARISON_2
        if(preanalisis.equals(complementologico)|preanalisis.equals(menos))
        {
           // System.out.println("LLAMARE A TERM DESDE COMPARISON");
            TERM();
            COMPARISON_2();
        }
        else if(preanalisis.equals(keybTrue)| preanalisis.equals(keybFalse)| preanalisis.equals(keybNull)| preanalisis.equals(keybThis)| preanalisis.equals(number)| preanalisis.equals(string)| preanalisis.equals(identificador)| preanalisis.equals(parentesisabre)| preanalisis.equals(keybSuper))
           
            {
            TERM();
            COMPARISON_2();
            }
    }
                
                
    void COMPARISON_2()
   {
        if(hayErrores) return;
                //-> > TERM COMPARISON_2
        if(preanalisis.equals(mayorque))
        {
            coincidir(mayorque);
            TERM();
            COMPARISON_2();
        }
            //-> >= TERM COMPARISON_2
       else if(preanalisis.equals(mayorque))
        {
            coincidir(mayorque);
            coincidir(igual);
            TERM();
            COMPARISON_2();
        }  
       //-> < TERM COMPARISON_2
       else if(preanalisis.equals(menorque))
        {
            coincidir(menorque);
            TERM();
            COMPARISON_2();
        }  
        // -> <= TERM COMPARISON_2
        else if(preanalisis.equals(menorque))
        {
            coincidir(menorque);
            coincidir(igual);
            TERM();
            COMPARISON_2();
        } 
                //->E
        else
                    return;
        
        
    }
                    
                    
    void TERM()
   {
        if(hayErrores) return;
            //-> FACTOR TERM_2

          if(preanalisis.equals(complementologico)|preanalisis.equals(menos))
        {
           FACTOR();
            TERM_2();
        }
        else if(preanalisis.equals(keybTrue)| preanalisis.equals(keybFalse)| preanalisis.equals(keybNull)| preanalisis.equals(keybThis)| preanalisis.equals(number)| preanalisis.equals(string)| preanalisis.equals(identificador)| preanalisis.equals(parentesisabre)| preanalisis.equals(keybSuper))
           
            {
           FACTOR();
            TERM_2();
            }
    }
    

   void TERM_2()
   {
        if(hayErrores) return;
           //-> - FACTOR TERM_2
        if(preanalisis.equals(menos)){
            coincidir(menos);
            FACTOR();
            TERM_2();
            
            
        }
            //->+ FACTOR TERM_2
        else if (preanalisis.equals(mas))
            {
            coincidir(mas);
            FACTOR();
            TERM_2();
            
            
            }
        
        else
            return;
    }
   
   
                            
    void FACTOR()
   {
        if(hayErrores) return;
          
        // -> UNARY FACTOR_2
        if(preanalisis.equals(complementologico)|preanalisis.equals(menos))
        {
            UNARY();
            FACTOR_2();
        }
        else if(preanalisis.equals(keybTrue)| preanalisis.equals(keybFalse)| preanalisis.equals(keybNull)| preanalisis.equals(keybThis)| preanalisis.equals(number)| preanalisis.equals(string)| preanalisis.equals(identificador)| preanalisis.equals(parentesisabre)| preanalisis.equals(keybSuper))
           
            {
            UNARY();
            FACTOR_2();
            }
    }
       
         
    
  void FACTOR_2()
   {
       //System.out.println("ENTRE AL  FACTOR_2");
        if(hayErrores) return;
           // -> / UNARY FACTOR_2
        if(preanalisis.equals(entre))
        {
           // System.out.println("ENTRE AL IF DEL FACTOR_2");
            coincidir(entre);
            UNARY();
            FACTOR_2();
        }
        
            //->* UNARY FACTOR_2
        else if(preanalisis.equals(asterisco))
            {
            coincidir(asterisco);
            UNARY();
            FACTOR_2();
            
            }
            //->E
        else
                return;
        
    }
       
   void UNARY()
   {
        if(hayErrores) return;
            //-> ! UNARY
        if(preanalisis.equals(complementologico))
        {
            coincidir(complementologico);
            UNARY();
        }
        
            //-> - UNARY
        else if(preanalisis.equals(menos))
            {
             coincidir(menos);
            UNARY();
            }
        
            //->CALL
        else if(preanalisis.equals(keybTrue)|preanalisis.equals(keybFalse)|preanalisis.equals(keybNull)|preanalisis.equals(keybThis)|preanalisis.equals(number)|preanalisis.equals(string)|preanalisis.equals(identificador)|preanalisis.equals(parentesisabre)|preanalisis.equals(keybSuper))
            {
                CALL();
            }
        
        
    }
   
   
   
   void CALL()
   {
        if(hayErrores) return;
            //-> PRIMARY CALL_2
        if(preanalisis.equals(keybTrue)|preanalisis.equals(keybFalse)|preanalisis.equals(keybNull)|preanalisis.equals(keybThis)|preanalisis.equals(number)|preanalisis.equals(string)|preanalisis.equals(identificador)|preanalisis.equals(parentesisabre)|preanalisis.equals(keybSuper))
            {
                PRIMARY();
                CALL_2();
            }
    }
   
   
      
      
   void CALL_2()
   {
        if(hayErrores) return;
            //-> ( ARGUMENTS_OPC ) CALL_2
        if(preanalisis.equals(parentesisabre)){
            coincidir(parentesisabre);
            ARGUMENTS_OPC();
            coincidir(parentesiscierra);
            CALL_2();
        }
        
        //-> . identificador CALL_2
        else if (preanalisis.equals(punto))
            {
            coincidir(punto);
            coincidir(identificador);
            CALL_2();
            
            }
        //-> Ɛ
        else
                return;
    }
   
   
         
         
   void CALL_OPC()
   {
        if(hayErrores) return;
            //->CALL. 
        if(preanalisis.equals(keybTrue)|preanalisis.equals(keybFalse)|preanalisis.equals(keybNull)|preanalisis.equals(keybThis)|preanalisis.equals(number)|preanalisis.equals(string)|preanalisis.equals(identificador)|preanalisis.equals(parentesisabre)|preanalisis.equals(keybSuper))
                {
            CALL();
            coincidir(punto);
        }
            //->E
         else
            return;
    }
   
   
            
    void PRIMARY()
   {
        if(hayErrores) return;
            //->true
        else if (preanalisis.equals(keybTrue))
            {
            coincidir(keybTrue);
            }
        else if (preanalisis.equals(keybFalse))
            {
            
            coincidir (keybFalse);
            }
        else if (preanalisis.equals(keybNull))
            {
            
            coincidir (keybNull);
            }
        else if (preanalisis.equals(keybThis))
            {
            
            coincidir (keybThis);
            }
        else if (preanalisis.equals(number))
            {
            
            coincidir (number);
            }
        else if (preanalisis.equals(string))
            {
            
            coincidir (string);
            }
        else if (preanalisis.equals(identificador))
            {
            // System.out.println("DENTRO DEL PRIMARY ID");
            coincidir (identificador);
            }
        else if (preanalisis.equals(parentesisabre))
            {
            
            coincidir (parentesisabre);
            EXPRESSION();
            coincidir (parentesiscierra);
            
            }
       else if (preanalisis.equals(keybSuper))
            {
            
            coincidir (keybSuper);
            coincidir (punto);
            coincidir (identificador);
            
            }
        
    }
   
   
               
   void FUNCTION()
   {
        if(hayErrores) return;
            //-> identificador ( PARAMETERS_OPC ) BLOCK
        if(preanalisis.equals(identificador)){
            coincidir(identificador);
            coincidir(parentesisabre);
            PARAMETERS_OPC();
            coincidir(parentesiscierra);
            BLOCK ();
        }
    }
   
   
                  
    void FUNCTIONS()
   {
        if(hayErrores) return;
            //->FUNCTION FUNCTIONS
        if(preanalisis.equals(identificador)){
            FUNCTION();
            FUNCTIONS();
        }
            //->E
        else
                return;
    }
   
   
                     
   void PARAMETERS_OPC()
   {
        if(hayErrores) return;
            //->PARAMETERS
        if(preanalisis.equals(identificador)) {
            PARAMETERS();

        }
            //->E
        else
            return;
    }
     
   void PARAMETERS()
   {
        if(hayErrores) return;
            //->identificador PARAMETERS_2
        if(preanalisis.equals(identificador)){
            coincidir(identificador);
            PARAMETERS_2();
        }
    }
          
   void PARAMETERS_2()
   {
        if(hayErrores) return;
            //-> , identificador PARAMETERS_2
        if(preanalisis.equals(coma)){
            coincidir(coma);
            coincidir(identificador);
            PARAMETERS_2();
            
            
        }
            //->E
        else
                return;
    }
               

   
   void ARGUMENTS_OPC()
   {
        if(hayErrores) return;
            //->ARGUMENTS

       if(preanalisis.equals(complementologico)|preanalisis.equals(menos))
        {       
        ARGUMENTS();
        }
        else if(preanalisis.equals(keybTrue)| preanalisis.equals(keybFalse)| preanalisis.equals(keybNull)| preanalisis.equals(keybThis)| preanalisis.equals(number)| preanalisis.equals(string)| preanalisis.equals(identificador)| preanalisis.equals(parentesisabre)| preanalisis.equals(keybSuper))
           
       {
            ARGUMENTS();    
       }    
          
         //->E
        else
            return;
            }
   
   
       void ARGUMENTS()
   {
        if(hayErrores) return;
            //->EXPRESSION ARGUMENTS_2
       if(preanalisis.equals(complementologico)|preanalisis.equals(menos))
        {       
        EXPRESSION();
        ARGUMENTS_2();
        }
        else if(preanalisis.equals(keybTrue)| preanalisis.equals(keybFalse)| preanalisis.equals(keybNull)| preanalisis.equals(keybThis)| preanalisis.equals(number)| preanalisis.equals(string)| preanalisis.equals(identificador)| preanalisis.equals(parentesisabre)| preanalisis.equals(keybSuper))
           
       {
        EXPRESSION();
        ARGUMENTS_2();  
       }   
    }
   
   void ARGUMENTS_2()
   {
        if(hayErrores) return;
            // -> , EXPRESSION ARGUMENTS_2
        if(preanalisis.equals(coma))
        {
            coincidir(coma);
            EXPRESSION();
            ARGUMENTS_2();
        }
            //-> E
         else
            return;
    }
  

    void coincidir(Token t)
    {           // t es un objeto, representa lo que nosotros estamos buscando
        if(hayErrores) return;
           // System.out.println("preanalisis.tipo = " + preanalisis.tipo + " t.tipo= " + t.tipo) ;
                    //t.tipo es el terminal que nosotros esperamos encontrarnos
        if(preanalisis.tipo == t.tipo){
            i++;     
            preanalisis = tokens.get(i);
            // tokensAceptadosPorParser.add(t);
        }
        else{
            hayErrores = true;
            System.out.println("Error en la posición " + preanalisis.posicion + ". Se esperaba un  " + t.tipo);

        }
    }
            
        


}

   
  
