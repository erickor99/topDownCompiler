/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.compiproyectofinaldosjordan;

/**
 *
 * @author erickortiz
 */

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class Principal 
{

    static boolean existenErrores = false;

    public static void main(String[] args) throws IOException 
    {
        ejecutarPrompt();
    }

    private static void ejecutarPrompt() throws IOException
    {
        InputStreamReader input = new InputStreamReader(System.in);
        BufferedReader reader = new BufferedReader(input);
        
        //for (;;) {
         // Loop body statements
        // ...
        //if (someCondition) {
        //break; // Exit the loop
        //  }
        for(;;)
        {
            System.out.print(">>> ");
            String linea = reader.readLine();
            
                //Used to check if the end of input has been reached:
            if(linea == null) break; // Presionar Ctrl + D // 
            
            //Se ejecuta cuando el loop haya sido interrumpido:
            ejecutar(linea);
            existenErrores = false;
        }
        
     
    
    
}
    
    
    private static void ejecutarArchivo(String path) throws IOException 
    {
        byte[] bytes = Files.readAllBytes(Paths.get(path));
        
        ejecutar(new String(bytes, Charset.defaultCharset()));

        // Se indica que existe un error
        if(existenErrores) System.exit(65);
    }


    private static void ejecutar(String source)
    {
//        Scanner scanner = new Scanner(source);
//        List<Token> tokens = scanner.scanTokens();
//        Parser parser = new Parser(tokens);
//        List<Token> tokensAceptadosPorParser = parser.parse();
        
        Scanner scanner = new Scanner(source);
        List<Token> tokens = scanner.scanTokens();

        Parser parser = new Parser(tokens);
        parser.parse();     
    
        
        
//
//        GeneradorPostfija gpf = new GeneradorPostfija(tokens);
//        List<Token> postfija = gpf.convertir();
//        GeneradorAST gast = new GeneradorAST(postfija);
//        Arbol programa = gast.generarAST();
//        programa.recorrer();


        
    }

    /*
    El método error se puede usar desde las distintas clases
    para reportar los errores:
    Interprete.error(....);
     */
    static void error(int linea, String mensaje)
    {
        reportar(linea, "", mensaje);
    }

    private static void reportar(int linea, String donde, String mensaje){
        System.err.println(
                "[linea " + linea + "] Error " + donde + ": " + mensaje
        );
        existenErrores = true;
    }

}

