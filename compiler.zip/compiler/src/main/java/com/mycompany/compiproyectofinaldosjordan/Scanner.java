/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.compiproyectofinaldosjordan;

/**
 *
 * @author erickortiz
 */
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Scanner 
{
        //Creating variables:
    private final String source;

    private final List<Token> tokens = new ArrayList<>();
       
    private static final Map<String, TipoToken> palabrasReservadas;
    
    
        //it gets executed immediately once the above code it's run:
    static {
        palabrasReservadas = new HashMap<>();    
        palabrasReservadas.put("clase", TipoToken.CLASS);
        palabrasReservadas.put("id", TipoToken.IDENTIFICADOR);
        palabrasReservadas.put("fun", TipoToken.FUN);
        palabrasReservadas.put("var", TipoToken.VAR);
        palabrasReservadas.put("for", TipoToken.FOR); 
        palabrasReservadas.put("if", TipoToken.IF);
        palabrasReservadas.put("else", TipoToken.ELSE);
        palabrasReservadas.put("print", TipoToken.PRINT);
        palabrasReservadas.put("return", TipoToken.RETURN);
        palabrasReservadas.put("while", TipoToken.WHILE);
        palabrasReservadas.put("or", TipoToken.OR);
        palabrasReservadas.put("and", TipoToken.AND);
        palabrasReservadas.put("true", TipoToken.TRUE);
        palabrasReservadas.put("false", TipoToken.FALSE);
        palabrasReservadas.put("null", TipoToken.NULL);
        palabrasReservadas.put("this", TipoToken.THIS);
        palabrasReservadas.put("number", TipoToken.NUMBER);
        palabrasReservadas.put("string", TipoToken.STRING);
        palabrasReservadas.put("super", TipoToken.SUPER);
       
       
        
    }
   
    Scanner(String source)
    {
        this.source = source + " ";
    }

    
    
    List<Token> scanTokens()
    {
        int estado = 0;
        char caracter = 0;
        String lexema = "";
        int inicioLexema = 0;
        boolean inComment = false; // Flag to indicate if inside a comment
        
        for(int i=0; i<source.length(); i++)
        {
            caracter = source.charAt(i);

            switch (estado)
            {


                case 0:
                      //  System.out.println("Apunto de analizar case 0");
                   // if(caracter == '*'){
                     //   tokens.add(new Token(TipoToken.ASTERISCO, "*", i + 1));
                    //}
                    if(caracter == ','){
                        tokens.add(new Token(TipoToken.COMA, ",", i + 1));
                    }
                    else if(caracter == '.'){
                        tokens.add(new Token(TipoToken.PUNTO, ".", i + 1));
                    }
                    else if(caracter == ';')
                     {tokens.add(new Token(TipoToken.PUNTOYCOMA,";",i+1));
                     }
                    else if(caracter == '(')
                     {tokens.add(new Token(TipoToken.PARENTESISABRE,"(",i+1));
                     }
                     else if(caracter == ')')
                     {tokens.add(new Token(TipoToken.PARENTESISCIERRA,")",i+1));
                     }
                     else if(caracter == '<')
                     {tokens.add(new Token(TipoToken.MENORQUE,"<",i+1));
                     }
                      else if(caracter == '>')
                     {tokens.add(new Token(TipoToken.MAYORQUE,">",i+1));
                     }
                      else if(caracter == '=')
                     {tokens.add(new Token(TipoToken.IGUAL,"=",i+1));
                     }
                      else if(caracter == '{')
                     {tokens.add(new Token(TipoToken.LLAVEABRE,"{",i+1));
                     }
                      else if(caracter == '}')
                     {tokens.add(new Token(TipoToken.LLAVECIERRA,"}",i+1));
                     }
                     else if(caracter == '>')
                     {tokens.add(new Token(TipoToken.MAYORQUE,">",i+1));
                     }
                       else if(caracter == '-')
                     {tokens.add(new Token(TipoToken.MENOS,"-",i+1));
                     }
                      else if(caracter == '+')
                     {tokens.add(new Token(TipoToken.MAS,"+",i+1));
                     }
                    //  else if(caracter == '/')
                    // {tokens.add(new Token(TipoToken.ENTRE,"/",i+1));
                    // }
                     else if(caracter == '!')
                     {tokens.add(new Token(TipoToken.COMPLEMENTOLOGICO,"!",i+1));
                     }

                     
                     
                       else if(caracter == '\r')
                     {
                         //System.out.println("ADENTRO DE SALTO DE LINEA");
                         tokens.add(new Token(TipoToken.NEWLINE,"\n",i+1));
                     }

                    //Para manejar STRINGS
                if (caracter == '"') 
                {
                estado = 3; // Enter the string state
                lexema = ""; // Reset the lexeme for the string
                inicioLexema = i; // Set the starting position of the string lexeme
                  }

                                     //COMENTARIOS
       /* if (caracter == '/' && i + 1 < source.length() && source.charAt(i + 1) == '*') 
        {
         estado = 4; // Enter the comment state
            i++; // Skip the asterisk
            lexema = "/"; // Set the lexeme to the slash
        } */
                else if (caracter == '/')
                {
                   // Check if it is the start of a comment
                  if (i + 1 < source.length() && source.charAt(i + 1) == '*')
                  {
                        inComment = true;
                        i++; // Skip the asterisk
                        estado = 4; // Enter the comment state
                   } 
                     
                }  
                
                if (Character.isAlphabetic(caracter))
                {
                    estado = 1;
                    lexema = lexema + caracter;
                    inicioLexema = i;
                }
                // Check for transition to State 2 (Number)
                else if (Character.isDigit(caracter))
                {
                    estado = 2;
                    lexema = lexema + caracter;
                    inicioLexema = i;
                }
                
                break;

                case 1:
                    
                    if(Character.isAlphabetic(caracter) || Character.isDigit(caracter) ){
                        lexema = lexema + caracter;
                       // System.out.println("lexema hasta ahora:" + lexema);
                    }
                    else
                    {
                        TipoToken tt = palabrasReservadas.get(lexema);
                        if(tt == null){
                            tokens.add(new Token(TipoToken.IDENTIFICADOR, lexema, inicioLexema + 1));
                        }
                        else{
                            tokens.add(new Token(tt, lexema, inicioLexema + 1));
                        }

                        estado = 0;
                        i--;
                        lexema = "";
                        inicioLexema = 0;
                    }
                    break;
                        
                  
                case 2:
                // State 2: Handling numbers
                if (Character.isDigit(caracter)) 
                {
                    lexema = lexema + caracter;
                   // System.out.println("lexema hasta ahora:" + lexema);
                } else {
                    tokens.add(new Token(TipoToken.NUMBER, lexema, inicioLexema + 1));

                    estado = 0;
                    i--;
                    lexema = "";
                    inicioLexema = 0;
                }
                break;
                /*
              case 3:
              if (caracter == '"') {
              tokens.add(new Token(TipoToken.STR, lexema, inicioLexema + 1));
              estado = 0;
              lexema = "";
              inicioLexema = 0;
              } else 
              {
                lexema = lexema + caracter;
              }
            break;
             case 3:
               if (caracter == '\n') 
               {
               tokens.add(new Token(TipoToken.NEWLINE,"\n" , inicioLexema + 1));
               estado = 0;
              lexema = "";
              inicioLexema = 0;
                }
               else {
                lexema = lexema + caracter;
                 }
                 break;

*/
                case 3: // PARA CADENAS:
                 if (caracter == '"') {
                  // Found the closing quotation mark, add the string token
                  tokens.add(new Token(TipoToken.STRING, lexema, inicioLexema + 1));
              estado = 0; // Return to the initial state
              lexema = ""; // Reset the lexeme for the next token
              } else {
                // Append characters to the string lexeme
             lexema += caracter;
                 }
                 break;


                
            case 4: // Comment state
           /*  if (caracter == '*' && i + 1 < source.length() && source.charAt(i + 1) == '/') {
             estado = 0; // Return to the initial state
             i++; // Skip the slash

             // Add the comment delimiter tokens
            // tokens.add(new Token(TipoToken.ENTRE, "/", inicioLexema + 1));
             //tokens.add(new Token(TipoToken.ASTERISCO, "*", inicioLexema + 2));

              //lexema = ""; // Reset the lexeme
            } else {
              //lexema = lexema + caracter; // Add characters to the lexeme
              }
             break;

             */
           // 
            if (caracter == '*' && i + 1 < source.length() && source.charAt(i + 1) == '/') 
            {
                inComment = false;
                i++; // Skip the slash
                estado = 0; // Return to the initial state
             }
             
            break;
                    
            }//final de SWITCH
            
            
        }//final de ciclo FOR
        
        tokens.add(new Token(TipoToken.EOF, "", source.length()));

        return tokens;
    }
    
    






}

    
    
