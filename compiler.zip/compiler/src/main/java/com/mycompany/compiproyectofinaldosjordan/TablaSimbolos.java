/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.compiproyectofinaldosjordan;

/**
 *
 * @author erickortiz
 */
import java.util.HashMap;
import java.util.Map;

public class TablaSimbolos
{
   
   private static final Map<String, Double> values = new HashMap<>();

   static public void imprimirTabla()
        {
           
            System.out.println(values);
        
        
        }
   static public void preguntarSiEstaVacio()
        {
         System.out.println("La tabla se encuentra vacia:" + values.isEmpty());
         
        }
   static public boolean existeIdentificador(String identificador)
    {
        
        return values.containsKey(identificador);
    }

    static Object obtener(String identificador) 
    {
        if (values.containsKey(identificador)) 
        {
            return values.get(identificador);
        }
        throw new RuntimeException("Variable no definida '" + identificador + "'.");
    }

  static public boolean asignar(String identificador, Double valor)
    
    {
        
       // System.out.println("ASIGNANDO identificador " + identificador + " y valor: "+ valor);
      values.put(identificador, valor);
      return true;
        
        //System.out.println("ASIGNANDO identificador " + identificador + " y valor: "+ valor);
    }


}
