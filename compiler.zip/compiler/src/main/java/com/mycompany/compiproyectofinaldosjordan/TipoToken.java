/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.compiproyectofinaldosjordan;

/**
 *
 * @author erickortiz
 */
public enum TipoToken 
{
    IDENTIFICADOR,

    // Palabras reservadas
    CLASS, FUN, VAR, FOR, IF, 
     ELSE, PRINT, RETURN, WHILE,  OR, AND,
     TRUE, FALSE, NULL, THIS, NUMBER, 
    STRING, SUPER,

    // Caracteres
    COMA, PUNTO, ASTERISCO, MENORQUE,IGUAL, PUNTOYCOMA,PARENTESISABRE,
    PARENTESISCIERRA,LLAVEABRE, LLAVECIERRA,DIFERENTEDE, IGUALCOMPARAR, MAYORQUE, MAYOROIGUALQUE, MENORIGUALQUE, MENOS,MAS,
    ENTRE, COMPLEMENTOLOGICO, 
    

  
    //SALTO DE LINEA
    NEWLINE,

    // Final de cadena
    EOF
    

}
