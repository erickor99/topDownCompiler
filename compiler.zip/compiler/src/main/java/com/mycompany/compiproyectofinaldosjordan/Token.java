/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.compiproyectofinaldosjordan;

/**
 *
 * @author erickortiz
 */
public class Token {

    final TipoToken tipo;
    final String lexema;
    final Object literal;

    final int posicion;

    public Token(TipoToken tipo, String lexema, int posicion)
    {
        this.tipo = tipo;
        this.lexema = lexema;
        this.posicion = posicion;
        literal = null;
    }

    public Token(TipoToken tipo, String lexema)
    {
        this.tipo = tipo;
        this.lexema = lexema;
        this.posicion = 0;
        literal = null;
    }
     public Token(TipoToken tipo, String lexema, Object literal)
    {
        this.tipo = tipo;
        this.lexema = lexema;
        this.posicion = 0;
        this.literal = literal;
    }

    @Override
    public boolean equals(Object o) 
    {
        if (!(o instanceof Token)) {
            return false;
        }

        if(this.tipo == ((Token)o).tipo){
            return true;
        }

        return false;
    }

    public String toString(){
        return tipo + " " + lexema + " ";
    }
    
    
        public String getLexema()
        {
         
        return lexema;
        
        }

//    public String toString()
//    {
//        return tipo + " " + lexema + " " + (literal == null ? " " : literal.toString());
//    }

    // Métodos auxiliares
    public boolean esOperando()
    {
        switch (this.tipo)
        {
            case IDENTIFICADOR:
            case NUMBER:
                return true;
            default:
                return false;
        }
    }

    public boolean esOperador()
    {
        switch (this.tipo){
            case MAS:
            case MENOS:
            case ASTERISCO:
            case ENTRE:
            case IGUAL:
            case MAYORQUE:
                 return true;
            default:
                return false;
           // case MAYOR_IGUAL:

        }
    }

    public boolean esPalabraReservada()
    {
        switch (this.tipo){
            case VAR:
            case IF:
            case PRINT:
            case ELSE:
                return true;
            default:
                return false;
        }
    }

    public boolean esEstructuraDeControl()
    {
        switch (this.tipo){
            case IF:
            case ELSE:
                return true;
            default:
                return false;
        }
    }

    public boolean precedenciaMayorIgual(Token t)
    {
        return this.obtenerPrecedencia() >= t.obtenerPrecedencia();
    }

    private int obtenerPrecedencia()
    {
        switch (this.tipo){
            case ASTERISCO:
            case ENTRE:
                return 3;
            case MAS:
            case MENOS:
                return 2;
            case IGUAL:
                return 1;
            case MAYORQUE:
            //case MAYOR_IGUAL:
                return 1;
        }

        return 0;
    }

    public int aridad()
    {
        switch (this.tipo) {
            case ASTERISCO:
            case ENTRE:
            case MAS:
            case MENOS:
            case IGUAL:
            case MAYORQUE:
            //case MAYOR_IGUAL:
                return 2;
        }
        return 0;
    }
}
